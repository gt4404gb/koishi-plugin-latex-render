import { Context } from 'koishi';
interface Config {
    width?: number;
    backgroundColor?: string;
    textColor?: string;
}
/**
 * 检测是否为 LaTeX 公式（增强版）
 */
export declare function containsLatex(content: string): boolean;
/**
 * 主渲染函数 - 使用 Puppeteer + KaTeX
 */
export declare function renderLatex(ctx: Context, content: string, config: Config): Promise<string>;
export {};
